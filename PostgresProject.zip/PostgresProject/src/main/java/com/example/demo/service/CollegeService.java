package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.College;

public interface CollegeService {

	College saveCollege(College college);

	List<College> fetchCollegeList();

	College fetchCollegeById(long id);

	void deleteCollegeById(Long id);

	College updateCollege(long collegeId, College college);


}
