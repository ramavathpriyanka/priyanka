package com.example.demo.service;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.College;
import com.example.demo.repository.CollegeRepository;

@Service
public class CollegeServiceImpl implements CollegeService{
	@Autowired
	CollegeRepository repository;

	@Override
	public College saveCollege(College college) {
		// TODO Auto-generated method stub
		return repository.save(college);
	}

	@Override
	public List<College> fetchCollegeList() {
		// TODO Auto-generated method stub
		return repository.findAll();
	}

	@Override
	public College fetchCollegeById(long id) {
		// TODO Auto-generated method stub
		return repository.findById(id).get();
	}

	@Override
	public void deleteCollegeById(Long id) {
		// TODO Auto-generated method stub
		repository.deleteById(id);
	}

	@Override
	public College updateCollege(long collegeId, College college) {
		// TODO Auto-generated method stub
		College college2=repository.findById(collegeId).get();
		 
		if(Objects.nonNull(college.getCollegeName())&& ! "".equals(college.getCollegeName())) {
			college2.setCollegeName(college.getCollegeName());
		}
		if (Objects.nonNull(college.getLocation())&& !"".equalsIgnoreCase(college.getLocation())) {
			college2.setLocation(college.getLocation());
		}
		return  repository.save(college2);
	}
	
	}
